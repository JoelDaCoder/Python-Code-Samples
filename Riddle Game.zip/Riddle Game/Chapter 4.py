
def DoorFourAccess(n1):
    print("Where does today come before yesterday?")
    StrS = "The dictionary"
    counter = 0
    while (n1 != (StrS)):
        n1 = input("Try Again: ")
        counter = counter + 1
        if counter == 1:
            print("Start Over")
            break

    if n1 == StrS:
        print("Door unlocked! Go to door 5")
        print("Word Bank Updated: Het, Erd, Gib, Sheou")

        print("What goes up but never comes down?")
        str1 = str(input("Guess the riddle: "))


def initialprint4():
    print("The screams seem to be getting further as if his brother was being taken away.")
    print("Ricky dashes and runs through the maze hoping there's no more doors")
    print("As he finishes his wish, he is faced with yet another door")
    print("")