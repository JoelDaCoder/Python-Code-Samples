
def DoorFiveAccess(n1):
    #print("")
    StrS = "The Big Red House"
    counter = 0
    while (n1 != (StrS)):
        n1 = input("Try Again: ")
        counter = counter
        if counter == 1:
            print("Start Over")
            break

    if n1 == StrS:
        print("Congratulations game complete! Download Season 2 to save Ricky's brother!")


        print("Decypher the word bank successfully")
        str1 = str(input("Decypher the word bank: "))


def initialprint5():
    print("Ricky finally sees daylight and one last door.")
    print("An envelope hangs from the door knob")
    print("You have successfully answered each riddle now decypher this and you shall know where your brother is being kept")
    print("")