import sys
sys.path.append("/Users/joelnava/IdeaProjects/Riddle Game/Chapter 1.py")


def DoorAccess(n1):
    print("What runs but you can't catch?")
    StrS = "A river"
    counter = 0
    # I could start a counter here at 0
    while (n1 != (StrS)):
        n1 = input("Try Again: ")
        counter = counter + 1
        if counter == 4:
            print("Start Over")
            break
        #if you have to try again, I'm gonna bump up the counter by 1
        #if the counter gets equal to 4
        #break

    if n1 == StrS:
        print("Door unlocked! Ricky runs through to another door")
        print("Word Bank Updated: Het")

        print("What runs but does not have legs?")
        str1 = str(input("Guess the riddle: "))



def initialprint():
    print("Suddenly awaken on a cold cement floor, Ricky wakes up wondering where he is.")
    print("He hears a scream from far away which he remembers as his brothers!!!")
    print("He tries to open the door but it's locked,")
    print("He then sees a riddle on the floor.")
    print("It reads out, ")
    print("")

def main():
    initialprint()
    print("What runs but you can't catch?")
    str1 = str(input("Guess the riddle: "))

    DoorAccess(str1)



main()