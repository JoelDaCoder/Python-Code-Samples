
def DoorTwoAccess(n1):
    print("What needs to broken before it is used?")
    StrS = "An egg"
    counter = 0
    # I could start a counter here at 0
    while (n1 != (StrS)):
        n1 = input("Try Again: ")
        counter = counter + 1
        if counter == 3:
            print("Start Over")
            break

    if n1 == StrS:
        print("Door unlocked! Go to door 3")
        print("Word Bank Updated: Het, Erd")

        print("What needs to broken before it is used?")
        str1 = str(input("Guess the riddle: "))


def initialprint2():
    print("As he gets down the hallway and turns right Ricky is met with another locked door")
    print("He hears a scream again but it is still far.")
    print("He looks up in dispair and sees another riddle that reads")
    print("")