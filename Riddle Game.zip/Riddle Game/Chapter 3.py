
def DoorThreeAccess(n1):
    print("What goes up but never comes down?")
    StrS = "Your age"
    counter = 0
    while (n1 != (StrS)):
        n1 = input("Try Again: ")
        counter = counter + 1
        if counter == 2:
            print("Start Over")
            break

    if n1 == StrS:
        print("Door unlocked! Go to door 4")
        print("Word Bank Updated: Het, Erd, Gib,")

        print("What goes up but never comes down?")
        str1 = str(input("Guess the riddle: "))


def initialprint3():
    print("Door 3 is located up a flight of stairs who seem endless.")
    print("This time there's no scream.")
    print("As he climbs he begins to read the new riddle on the stairs.")
    print("")