#Author: Joel Navarrete
#09/18/2020
#This is a riddle game it contains 5 chapters


#These prints are before each chapter to give user an idea where Ricky is going
#Added a warning print statement to let user know how to input answer
def initialprint():
    print("Suddenly awaken on a cold cement floor, Ricky wakes up wondering where he is.")
    print("He hears a scream from far away which he remembers as his brothers!!!")
    print("He tries to open the door but it's locked,")
    print("He then sees a riddle on the floor.")
    print("It reads out, ")
    print("WARNING! only capitalize the first word of your answer. Example: A airplane, The boat, or An object.") #add warning to user
    print("")

def initialprint2():
    print("As he gets down the hallway and turns right Ricky is met with another locked door")
    print("He hears a scream again but it is still far.")
    print("He looks up in dispair and sees another riddle that reads")
    print("WARNING! only capitalize the first word of your answer. Example: A airplane, The boat, or An object.")
    print("")

def initialprint3():
    print("Door 3 is located up a flight of stairs who seem endless.")
    print("This time there's no scream.")
    print("As he climbs he begins to read the new riddle on the stairs.")
    print("WARNING! only capitalize the first word of your answer. Example: A airplane, The boat, or An object.")
    print("")

def initialprint4():
    print("The screams seem to be getting further as if his brother was being taken away.")
    print("Ricky dashes and runs through the maze hoping there's no more doors")
    print("As he finishes his wish, he is faced with yet another door")
    print("WARNING! only capitalize the first word of your answer. Example: A airplane, The boat, or An object.")
    print("")

def initialprint5():
    print("Ricky finally sees daylight and one last door.")
    print("An envelope hangs from the door knob")
    print("You have successfully answered each riddle! Solve the word bank to know where your brother is.")
    print("WARNING! only capitalize each starting word. Example: He Is Not Here")
    print("")

#chapter 1
def DoorAccess():
    print("What runs but you can't catch?") #state the riddle
    n1 = str(input("Guess the riddle: "))
    StrS = "A river" #answer to riddle for each chapter here
    counter = 0
    #I could start a counter here at 0
    while (n1 != (StrS)):
        n1 = input("Try Again: ")
        counter = counter + 1
        if counter == 4:
            #print("Start Over")
            return False
        #if you have to try again, I'm gonna bump up the counter by 1
        #if the counter gets equal to 4
        #break

    if n1 == StrS:
        print("Door unlocked! Ricky runs through to another door")
        print("Word Bank Updated: Het") #word back words are scrabbled to give a more difficulty level for chapter 5
        print("")
        return True

        #print("What runs but does not have legs?")
        #str1 = str(input("Guess the riddle: "))

#chapter 2 where the user needs to guess with only 3 attempts
def DoorTwoAccess():
    print("What needs to broken before it is used?")
    n1 = input("Guess the riddle: ")
    StrS = "An egg"
    counter = 0
    while (n1 != (StrS)):
        n1 = input("Try Again: ")
        counter = counter + 1
        if counter == 3: #change counter each chapter to up difficulty level
            #print("Start Over")
            return False

    if n1 == StrS:
        print("Door unlocked! Go to door 3")
        print("Word Bank Updated: Het, Erd")
        print("")
        return True
        #print("What needs to broken before it is used?")
        #str1 = str(input("Guess the riddle: "))

#chapter 3 begins only 2 attempts
def DoorThreeAccess():
    print("What goes up but never comes down?")
    n1 = input("Guess the riddle: ")
    StrS = "Your age"
    counter = 0
    while (n1 != (StrS)):
        n1 = input("Try Again: ")
        counter = counter + 1
        if counter == 2:
            #print("Start Over")
            return False

    if n1 == StrS:
        print("Door unlocked! Go to door 4")
        print("Word Bank Updated: Het, Erd, Gib,")
        print("")
        return True
        #print("What goes up but never comes down?")
        #str1 = str(input("Guess the riddle: "))

#chapter 4 door access
def DoorFourAccess():
    print("Where does today come before yesterday?")
    n1 = input("Guess the riddle: ")
    StrS = "The dictionary"
    counter = 0
    while (n1 != (StrS)):
        n1 = input("Try Again: ")
        counter = counter + 1
        if counter == 1:
            #print("Start Over")
            return False

    if n1 == StrS:
        print("Door unlocked! Go to door 5")
        print("Word Bank Updated: Het, Erd, Gib, Sheou")
        print("")
        return True
        #print("What goes up but never comes down?")
        #str1 = str(input("Guess the riddle: "))

#last chapter in game
#will give user a congrats message if completed
def DoorFiveAccess():
    print("Decipher the word bank successfully.")
    print("Word Bank: Het, Erd, Gib, Sheou")
    StrS = "The Big Red House"
    n1 = input("Decipher the phrase in the word bank: ")
    counter = 0
    while (n1 != (StrS)):
        n1 = input("Try Again: ")
        counter = counter + 1
        if counter == 1:
            #print("Start Over")
            return False

    if n1 == StrS:
        print("Congratulations game complete! Download Season 2 to save Ricky's brother!")
        return True
        #print("Decypher the word bank successfully")
        #str1 = str(input("Decypher the word bank: "))


#this main function includes all door access functions and chapter narratives
#if user gets to last chapter give them a clue for them to replay your game! line 173
def main():
    continue_playing = 'Yes'
    while continue_playing == 'Yes':
        initialprint()
        if DoorAccess():
            initialprint2()
            if DoorTwoAccess():
                initialprint3()
                if DoorThreeAccess():
                    initialprint4()
                    if DoorFourAccess():
                        initialprint5()
                        if DoorFiveAccess():
                            print("Congratulations game complete! Download Season 2 to save Ricky's brother!")
                        else:
                            continue_playing = input("Do you want to start from chapter 1? ")
                            if continue_playing == 'No':
                                print("Sorry you could not get past this chapter. Here's a clue for next time The B_g Re_ H__se.") #add a space so when user types a response a space is already there
                    else:
                        continue_playing = input("Do you want to start from chapter 1? ")
                        if continue_playing == 'No':
                            print("Sorry you could not get past this chapter. Exiting game.")
                else:
                    continue_playing = input("Do you want to start from chapter 1? ")
                    if continue_playing == 'No':
                        print("Sorry you could not get past this chapter. Exiting game.")
            else:
                continue_playing = input("Do you want to start from chapter 1? ")
                if continue_playing == 'No':
                    print("Sorry you could not get past this chapter. Exiting game.")
        else:
            continue_playing = input("Do you wish to continue playing? ")
            if continue_playing == 'No':
                print("Sorry you could not get past this chapter. Exiting game.")

main()